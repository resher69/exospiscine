/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agardet <agardet@student.42lyon.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/17 09:24:52 by chervy            #+#    #+#             */
/*   Updated: 2020/10/17 17:44:35 by agardet          ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int		ft_check_nb(char c)
{
	if (c >= 1 && c <= 4)
		return (1);
	return (0);
}

int		ft_check_space(char c)
{
	if (c == ' ')
		return (1);
	return (0);
}

int		ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int		ft_check_arg(char *str)
{
	int i;

	i = 0;
	if (ft_strlen(str) != 30)
	{
		write(1, "ERROR\n", 6);
		return (0);
	}
	while (str[i] != '\0')
	{
		if (ft_check_nb(str[i]) || ft_check_space(str[i]) == 1)
			i++;
		else
		{
			write(1, "ERROR\n", 6);
			return (0);
		}
		return (i);
	}
}
void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	if (-2147483648 == nb)
	{
		write(1, "-2147483648", 11);
	}
	else if (nb > 0)
	{
		if (nb >= 10)
			ft_putnbr(nb / 10);
		ft_putchar(nb % 10 + '0');
	}
	else if (nb == 0)
	{
		ft_putchar('0');
	}
	else
	{
		ft_putchar('-');
		ft_putnbr(nb * -1);
	}
}

void	ft_create_view(int view[4][4], char *str)
{
	int x;
	int y;
	int i;

	x = 0;
	y = 0;
	i = 0;
	while (str[i] != '\0')
	{
		if ((i + 1) % 8 == 0 && i != 0)
		{
			x = 0;
			y++;
		}
		if (i % 2 == 0)
		{
			view[x][y] = str[i];
			x++;
		}
		i++;
	}
}

void	ft_print_map(int map[4][4])
{
	int x;
	int y;

	x = 0;
	y = 0;
	while (y < 4)
	{
		while (x < 4)
		{
			ft_putchar(map[x][y]);
			if (x < 3)
				write(1, " ", 1);
			x++;
		}
		ft_putchar('\n');
		x = 0;
		y++;
	}
}

int		ft_is_present_col(int nbr, int x, int map[4][4])
{
	int i;

	i = 0;
	while (i < 4)
	{
		if (nbr == map[x][i])
			return (1);
		i++;
	}
	return (0);
}

int		ft_is_present_row(int nbr, int y, int map[4][4])
{
	int i;

	i = 0;
	while (i < 4)
	{
		if (nbr == map[i][y])
			return (1);
		i++;
	}
	return (0);
}

int		ft_check_col(int x, int y, int map[4][4], int view[4][4])
{
	int grw;
	int i;

	grw = 1;
	i = 0;
	if (map[x][i] < map[x][i + 1])
		grw++;
	if (map[x][i] < map[x][i + 2]
			&& map[x][i + 1] < map[x][i + 2])
		grw++;
	if (map[x][i] < map[x][i + 3]
			&& map[x][i + 1] < map[x][i + 3]
			&& map[x][i + 2] < map[x][i + 3])
		grw++;
	if (grw + 48 == view[x][y])
		return (1);
	else
		return (0);
}

int		ft_check_row(int x, int y, int map[4][4], int view[4][4])
{
	int grw;
	int i;

	grw = 1;
	i = 0;
	if (map[i][x] < map[i + 1][x])
		grw++;
	if (map[i][x] < map[i + 2][x]
			&& map[i + 1][x] < map[i + 2][x])
		grw++;
	if (map[i][x] < map[i + 3][x]
			&& map[i + 1][x] < map[i + 3][x]
			&& map[i + 2][x] < map[i + 3][x])
		grw++;
	if (grw + 48 == view[x][y])
		return (1);
	else
		return (0);
}

int		main(int argc, char *argv[])
{
	int view[4][4];
	int map[4][4];

	(void)argc;
	ft_create_view(view, argv[1]);
	ft_create_view(map, argv[2]);
	ft_print_map(view);
	ft_putchar('\n');
	ft_print_map(map);
	ft_putnbr(ft_is_present_row('1', 0, map));
	ft_putnbr(ft_check_row(0, 2, map, view));
	return (0);
}
